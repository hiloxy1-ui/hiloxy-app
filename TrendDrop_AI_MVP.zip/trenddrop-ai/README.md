# TrendDrop AI — deployable MVP

This repository is a working front-end/admin MVP for an AI dropshipping operating system. It includes:

- Public landing/storefront concept
- Super Admin dashboard
- AI Trend Radar with product opportunity scoring
- Landed-cost and gross-margin calculations
- Supplier connector screen
- Product approval controls
- Order/tracking dashboard
- Analytics and automation settings
- API route `/api/trends`
- API health route `/api/health`
- Supabase starter schema
- `.env.example` for production credentials

## 1. Run locally

```bash
npm install
npm run dev
```

Open `http://localhost:3000` and `http://localhost:3000/admin`.

## 2. Put it online with GitHub + Vercel

Create a new GitHub repository, then from this folder:

```bash
git init
git add -A
git commit -m "Initial TrendDrop AI MVP"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/trenddrop-ai.git
git push -u origin main
```

In Vercel:

1. Sign in and choose **Add New → Project**.
2. Import the `trenddrop-ai` GitHub repository.
3. Vercel should detect Next.js automatically.
4. Deploy. You will receive a public `*.vercel.app` URL.
5. In **Project Settings → Domains**, attach your own domain when ready.
6. In **Project Settings → Environment Variables**, add production keys from `.env.example`.
7. Redeploy after adding/changing environment variables.

## 3. Production database/auth

Create a Supabase project. Run `supabase/schema.sql` in Supabase SQL Editor, then add:

```text
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=...
SUPABASE_SERVICE_ROLE_KEY=...
```

Before real customer data is used, implement and test Row Level Security (RLS) policies.

## 4. China supplier integration

For CJdropshipping production integration, obtain the account/API credentials and keep them server-side. The recommended build sequence is:

1. Authentication/token service
2. Product search/import
3. Variant and inventory sync
4. Freight calculation per destination
5. Order creation
6. Order payment/confirmation according to CJ workflow
7. Tracking synchronization
8. Webhook/polling reconciliation and failure handling

Do not expose supplier credentials in browser code.

## 5. AI trend engine for the production version

The current MVP contains deterministic sample scoring so the interface is usable immediately. Replace mock signals with licensed/approved data sources and server-side jobs that calculate:

- Search-interest acceleration
- Social/video engagement velocity
- Supplier order velocity and inventory
- Price and shipping changes
- Competition/saturation
- Review quality and return risk
- Market-specific demand
- Contribution margin after expected ad spend and fees

The AI should suggest products, but retain human approval by default until the system has proven reliable.

## 6. Payments

Add your Stripe or other supported payment provider credentials only through server-side environment variables. Before accepting live orders, configure:

- Payment webhooks
- Tax/VAT handling for target markets
- Refund workflow
- Chargeback handling
- Fraud controls
- Terms, privacy, returns and shipping policies

## 7. What remains before a real launch

This MVP is deployable now, but a commercial production launch still requires live integrations for supplier APIs, payments, authentication, database persistence, trend-data providers, transactional email/SMS, legal policies, observability, backups, and end-to-end order/refund testing.
