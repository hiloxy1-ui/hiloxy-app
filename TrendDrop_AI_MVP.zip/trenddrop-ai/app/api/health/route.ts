export async function GET() {
  return Response.json({ ok: true, service: "TrendDrop AI", version: "0.1.0" });
}
