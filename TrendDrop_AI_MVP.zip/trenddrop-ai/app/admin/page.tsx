"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { orders, products } from "@/lib/mock-data";
import { grossMargin, grossProfit, landedCost, opportunityScore } from "@/lib/scoring";

type View = "Dashboard" | "Trend Radar" | "Suppliers" | "Products" | "Orders" | "Analytics" | "Settings";

export default function Admin() {
  const [view, setView] = useState<View>("Dashboard");
  const [approved, setApproved] = useState<string[]>(["TD-1042"]);
  const ranked = useMemo(() => [...products].sort((a,b) => opportunityScore(b)-opportunityScore(a)), []);
  const approve = (id:string) => setApproved(x => x.includes(id) ? x.filter(i => i !== id) : [...x,id]);

  return <div className="adminShell">
    <aside className="sidebar">
      <Link className="brand sideBrand" href="/"><span className="brandMark">T</span>TrendDrop <b>AI</b></Link>
      <div className="workspace"><small>WORKSPACE</small><strong>Global Commerce</strong><span>Owner account</span></div>
      <nav className="sideNav">{(["Dashboard","Trend Radar","Suppliers","Products","Orders","Analytics","Settings"] as View[]).map(v => <button className={view===v?"active":""} key={v} onClick={() => setView(v)}><span>{icon(v)}</span>{v}</button>)}</nav>
      <div className="agentBox"><span className="agentOrb">✦</span><div><strong>AI Manager</strong><small>4 recommendations ready</small></div></div>
    </aside>
    <main className="adminMain">
      <header className="adminHeader"><div><small>TRENDDROP AI / {view.toUpperCase()}</small><h1>{view}</h1></div><div className="headerActions"><span className="statusPill"><i/> AI engine online</span><button className="button primary">+ Import product</button></div></header>
      {view === "Dashboard" && <Dashboard ranked={ranked}/>} 
      {view === "Trend Radar" && <TrendRadar ranked={ranked} approved={approved} approve={approve}/>} 
      {view === "Suppliers" && <Suppliers/>}
      {view === "Products" && <Products approved={approved} approve={approve}/>} 
      {view === "Orders" && <Orders/>}
      {view === "Analytics" && <Analytics/>}
      {view === "Settings" && <Settings/>}
    </main>
  </div>
}

function Dashboard({ranked}:{ranked:typeof products}){
  return <>
    <section className="kpiGrid">
      <Kpi label="Revenue today" value="$18,450" delta="+18.2%"/><Kpi label="Estimated net profit" value="$5,720" delta="+12.4%"/><Kpi label="Orders" value="487" delta="+8.1%"/><Kpi label="Avg. ROAS" value="3.8×" delta="+0.4×"/>
    </section>
    <section className="adminGrid twoThirds">
      <div className="card"><div className="cardTitle"><div><small>AI TREND RADAR</small><h2>Top opportunities</h2></div><span className="statusPill"><i/> refreshed</span></div>
        <div className="tableWrap"><table><thead><tr><th>Product</th><th>Stage</th><th>Landed</th><th>Sell</th><th>Margin</th><th>AI Score</th></tr></thead><tbody>{ranked.map(p=><tr key={p.id}><td><strong>{p.name}</strong><small>{p.supplier}</small></td><td><span className={`tag ${p.stage.toLowerCase()}`}>{p.stage}</span></td><td>${landedCost(p).toFixed(2)}</td><td>${p.sell}</td><td>{grossMargin(p).toFixed(0)}%</td><td><b className="scoreMini">{opportunityScore(p)}</b></td></tr>)}</tbody></table></div>
      </div>
      <div className="card"><div className="cardTitle"><div><small>AI MANAGER</small><h2>Actions</h2></div><span className="agentOrb">✦</span></div>
        <div className="actionItem"><b>Launch</b><p>Magnetic stand has strong margin and low saturation.</p><button>Review product →</button></div>
        <div className="actionItem warning"><b>Reprice</b><p>Garment steamer shipping cost increased in UAE.</p><button>Review pricing →</button></div>
        <div className="actionItem danger"><b>Pause</b><p>Pet paw cleaner competition is now above your threshold.</p><button>Review risk →</button></div>
      </div>
    </section>
    <section className="adminGrid halves"><div className="card"><div className="cardTitle"><div><small>FULFILLMENT</small><h2>Recent orders</h2></div></div>{orders.slice(0,3).map(o=><div className="orderLine" key={o.id}><strong>{o.id}</strong><span>{o.customer}</span><span>{o.status}</span><b>${o.total}</b></div>)}</div><div className="card"><div className="cardTitle"><div><small>PROFIT GUARDRAIL</small><h2>Current rule set</h2></div></div><div className="rule"><span>Minimum gross margin</span><b>45%</b></div><div className="rule"><span>Minimum AI opportunity score</span><b>80/100</b></div><div className="rule"><span>Maximum supplier handling</span><b>3 days</b></div><div className="rule"><span>Auto-publish</span><b>OFF</b></div></div></section>
  </>
}

function TrendRadar({ranked,approved,approve}:{ranked:typeof products,approved:string[],approve:(id:string)=>void}){
 return <div className="card"><div className="cardTitle"><div><small>PRODUCT DISCOVERY</small><h2>AI-ranked opportunities</h2></div><div className="filterPills"><span>All markets</span><span>Score ≥ 70</span></div></div><div className="productCards">{ranked.map(p=><article className="productCard" key={p.id}><div className="productTop"><span className={`tag ${p.stage.toLowerCase()}`}>{p.stage}</span><b className="bigScore">{opportunityScore(p)}<small>/100</small></b></div><h3>{p.name}</h3><p>{p.category} · {p.supplier}</p><div className="scoreBars"><Bar label="Trend" val={p.trend}/><Bar label="Supplier" val={p.supplierScore}/><Bar label="Low competition" val={100-p.competition}/><Bar label="Low return risk" val={100-p.returnRisk}/></div><div className="profitBox"><div><small>Landed</small><b>${landedCost(p).toFixed(2)}</b></div><div><small>Retail</small><b>${p.sell}</b></div><div><small>Gross profit</small><b>${grossProfit(p).toFixed(2)}</b></div></div><p className="marketText">Best markets: {p.markets.join(" · ")}</p><button onClick={()=>approve(p.id)} className={`approveBtn ${approved.includes(p.id)?"approved":""}`}>{approved.includes(p.id)?"✓ Approved for store":"Approve product"}</button></article>)}</div></div>
}

function Suppliers(){return <div className="adminGrid thirds"><Supplier name="CJdropshipping" status="API ready" score="91/100" detail="Product search · inventory · freight · orders · tracking"/><Supplier name="AliExpress / DSers" status="Connector planned" score="87/100" detail="Supplier comparison · bulk order routing · tracking sync"/><Supplier name="Alibaba / sourcing agents" status="Phase 2" score="89/100" detail="Scale winning SKUs · factory quotes · private label"/></div>}
function Supplier({name,status,score,detail}:{name:string,status:string,score:string,detail:string}){return <div className="card supplierCard"><div className="supplierLogo">CN</div><span className="statusPill"><i/>{status}</span><h2>{name}</h2><p>{detail}</p><div className="rule"><span>Reliability score</span><b>{score}</b></div><button className="button">Configure connector</button></div>}
function Products({approved,approve}:{approved:string[],approve:(id:string)=>void}){return <div className="card"><div className="cardTitle"><div><small>CATALOG</small><h2>Store products</h2></div></div><div className="tableWrap"><table><thead><tr><th>Product</th><th>Supplier</th><th>Retail</th><th>Margin</th><th>Status</th><th></th></tr></thead><tbody>{products.map(p=><tr key={p.id}><td><strong>{p.name}</strong><small>{p.id}</small></td><td>{p.supplier}</td><td>${p.sell}</td><td>{grossMargin(p).toFixed(0)}%</td><td>{approved.includes(p.id)?<span className="tag rising">Approved</span>:<span className="tag">Draft</span>}</td><td><button className="tableBtn" onClick={()=>approve(p.id)}>{approved.includes(p.id)?"Remove":"Approve"}</button></td></tr>)}</tbody></table></div></div>}
function Orders(){return <div className="card"><div className="cardTitle"><div><small>FULFILLMENT QUEUE</small><h2>Orders & tracking</h2></div></div><div className="tableWrap"><table><thead><tr><th>Order</th><th>Customer</th><th>Market</th><th>Total</th><th>Fulfillment</th><th>Tracking</th></tr></thead><tbody>{orders.map(o=><tr key={o.id}><td><strong>{o.id}</strong></td><td>{o.customer}</td><td>{o.market}</td><td>${o.total}</td><td><span className="tag rising">{o.status}</span></td><td>{o.tracking}</td></tr>)}</tbody></table></div></div>}
function Analytics(){return <div className="adminGrid halves"><div className="card"><div className="cardTitle"><div><small>UNIT ECONOMICS</small><h2>Margin snapshot</h2></div></div><div className="bigMetric">31.0%<small>estimated net margin</small></div><div className="rule"><span>Gross sales</span><b>$92,840</b></div><div className="rule"><span>COGS + freight</span><b>$37,210</b></div><div className="rule"><span>Advertising</span><b>$18,440</b></div><div className="rule"><span>Fees + refunds</span><b>$8,410</b></div></div><div className="card"><div className="cardTitle"><div><small>MARKET SIGNAL</small><h2>Revenue mix</h2></div></div><Bar label="UAE" val={82}/><Bar label="UK" val={63}/><Bar label="Kenya" val={47}/><Bar label="Saudi Arabia" val={39}/><Bar label="Other" val={23}/></div></div>}
function Settings(){return <div className="adminGrid halves"><div className="card"><div className="cardTitle"><div><small>AUTOMATION</small><h2>AI control rules</h2></div></div><Setting label="Auto-import discovered products" enabled={false}/><Setting label="Require approval before publish" enabled/><Setting label="Auto-route paid orders" enabled/><Setting label="Pause if margin falls below 35%" enabled/><Setting label="Block branded / IP-risk products" enabled/></div><div className="card"><div className="cardTitle"><div><small>INTEGRATIONS</small><h2>Production connections</h2></div></div><div className="integration"><span>Supabase</span><b>ADD KEYS</b></div><div className="integration"><span>CJdropshipping</span><b>ADD KEYS</b></div><div className="integration"><span>Stripe</span><b>ADD KEYS</b></div><div className="integration"><span>AI provider</span><b>ADD KEY</b></div><p className="muted">Secret credentials belong in server-side environment variables, never in client code.</p></div></div>}
function Setting({label,enabled}:{label:string,enabled:boolean}){return <div className="setting"><span>{label}</span><span className={`switch ${enabled?"on":""}`}><i/></span></div>}
function Kpi({label,value,delta}:{label:string,value:string,delta:string}){return <div className="kpi card"><small>{label}</small><strong>{value}</strong><span>{delta} this period</span></div>}
function Bar({label,val}:{label:string,val:number}){return <div className="barRow"><div><span>{label}</span><b>{val}</b></div><div className="barTrack"><i style={{width:`${val}%`}}/></div></div>}
function icon(v:View){return ({Dashboard:"⌂","Trend Radar":"✦",Suppliers:"⌘",Products:"▦",Orders:"⇄",Analytics:"◫",Settings:"⚙"} as Record<View,string>)[v]}
