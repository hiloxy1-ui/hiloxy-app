import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "TrendDrop AI — AI Dropshipping Operating System",
  description: "Discover trends, compare China suppliers, score margins, publish products and automate fulfillment."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
