import { products } from "@/lib/mock-data";
import { opportunityScore, grossMargin, landedCost } from "@/lib/scoring";

export async function GET() {
  const ranked = products
    .map((p) => ({ ...p, opportunityScore: opportunityScore(p), landedCost: landedCost(p), grossMargin: Number(grossMargin(p).toFixed(1)) }))
    .sort((a, b) => b.opportunityScore - a.opportunityScore);

  return Response.json({ generatedAt: new Date().toISOString(), products: ranked });
}
