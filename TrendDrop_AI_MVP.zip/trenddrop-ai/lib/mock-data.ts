export type TrendProduct = {
  id: string;
  name: string;
  category: string;
  supplier: string;
  cost: number;
  shipping: number;
  sell: number;
  trend: number;
  supplierScore: number;
  competition: number;
  returnRisk: number;
  stage: "Emerging" | "Rising" | "Viral" | "Saturated";
  markets: string[];
};

export const products: TrendProduct[] = [
  { id: "TD-1042", name: "Magnetic Foldable Phone Stand", category: "Mobile", supplier: "CJdropshipping", cost: 4.8, shipping: 3.1, sell: 24.99, trend: 93, supplierScore: 91, competition: 34, returnRisk: 12, stage: "Rising", markets: ["UAE", "UK", "Kenya"] },
  { id: "TD-1038", name: "Portable Mini Garment Steamer", category: "Home", supplier: "AliExpress / DSers", cost: 9.2, shipping: 4.6, sell: 39.99, trend: 88, supplierScore: 86, competition: 43, returnRisk: 18, stage: "Emerging", markets: ["Saudi Arabia", "UAE", "South Africa"] },
  { id: "TD-1029", name: "Rechargeable Motion Sensor Light", category: "Home", supplier: "Alibaba", cost: 5.7, shipping: 3.8, sell: 27.99, trend: 84, supplierScore: 89, competition: 49, returnRisk: 9, stage: "Rising", markets: ["UK", "Kenya", "Ghana"] },
  { id: "TD-1014", name: "Pet Paw Cleaning Cup", category: "Pets", supplier: "CJdropshipping", cost: 3.4, shipping: 3.2, sell: 19.99, trend: 78, supplierScore: 94, competition: 73, returnRisk: 11, stage: "Saturated", markets: ["USA", "UK"] }
];

export const orders = [
  { id: "#TD90218", customer: "Amina K.", market: "UAE", total: 49.98, status: "Supplier confirmed", tracking: "CJ•••2841" },
  { id: "#TD90217", customer: "Daniel M.", market: "Kenya", total: 27.99, status: "In transit", tracking: "YT•••7730" },
  { id: "#TD90216", customer: "Sarah J.", market: "UK", total: 39.99, status: "Paid — routing", tracking: "Pending" },
  { id: "#TD90215", customer: "Khalid A.", market: "Saudi Arabia", total: 79.98, status: "Delivered", tracking: "CJ•••1039" }
];
