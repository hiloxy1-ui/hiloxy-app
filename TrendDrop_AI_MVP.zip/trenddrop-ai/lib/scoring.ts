import type { TrendProduct } from "./mock-data";

export function landedCost(p: TrendProduct) {
  return p.cost + p.shipping;
}

export function grossProfit(p: TrendProduct) {
  return p.sell - landedCost(p);
}

export function grossMargin(p: TrendProduct) {
  return (grossProfit(p) / p.sell) * 100;
}

export function opportunityScore(p: TrendProduct) {
  const margin = Math.min(100, grossMargin(p) * 1.6);
  const competitionAdvantage = 100 - p.competition;
  const riskAdvantage = 100 - p.returnRisk;
  return Math.round(
    p.trend * 0.35 + p.supplierScore * 0.2 + margin * 0.25 + competitionAdvantage * 0.1 + riskAdvantage * 0.1
  );
}
