# TrendDrop AI — Production Launch Checklist

## Stage A — Put the MVP on the internet
- Create GitHub repository and push this folder.
- Import repository into Vercel.
- Confirm `/`, `/admin`, `/api/health`, and `/api/trends` work.
- Add a custom domain in Vercel Project Settings → Domains.

## Stage B — Make accounts and data real
- Create Supabase production project.
- Apply database schema and implement Row Level Security policies.
- Add authentication for Owner/Admin/Operator roles.
- Replace mock products/orders with database queries.

## Stage C — Connect sourcing and fulfillment
- Create/verify CJdropshipping API access.
- Implement server-only token storage and refresh.
- Implement product, variant, inventory and freight synchronization.
- Implement order creation, fulfillment state reconciliation and tracking.
- Add secondary connectors (DSers/AliExpress, Alibaba or sourcing agents) only under their approved API/partner terms.

## Stage D — Connect trend intelligence
- Connect approved trend/search/social data providers.
- Store raw trend signals and timestamps.
- Recalculate opportunity score on a schedule.
- Add duplicate-product clustering and saturation detection.
- Add IP/brand/restricted-product risk filters.

## Stage E — Take live payments
- Configure payment provider.
- Implement server-side checkout and signed webhooks.
- Prevent fulfillment until payment is confirmed.
- Implement refund, cancellation and chargeback workflows.
- Add taxes/duties logic for selling markets.

## Stage F — Customer operations
- Transactional order confirmation.
- Shipment and tracking notifications.
- Customer account/order lookup.
- Returns/refunds portal.
- Support inbox/chat integration.

## Stage G — Production safety
- Secrets only in server-side environment variables.
- Audit logs for admin actions.
- Idempotency on payment and supplier-order webhooks.
- Rate limiting and bot protection.
- Backups, uptime monitoring and error reporting.
- Terms of Service, Privacy Policy, Return Policy and Shipping Policy reviewed for target markets.

## Launch gate
Do not enable automatic supplier purchasing until a full test order has successfully completed: payment → supplier order → dispatch → tracking → delivery/refund reconciliation.
