import Link from "next/link";
import { products } from "@/lib/mock-data";
import { opportunityScore } from "@/lib/scoring";

export default function Home() {
  const winners = [...products].sort((a,b) => opportunityScore(b)-opportunityScore(a)).slice(0,3);
  return (
    <main>
      <header className="topbar">
        <Link className="brand" href="/"><span className="brandMark">T</span>TrendDrop <b>AI</b></Link>
        <nav className="nav"><a href="#engine">How it works</a><a href="#winners">Trend radar</a><Link className="button ghost" href="/admin">Super Admin</Link></nav>
      </header>

      <section className="hero">
        <div className="heroCopy">
          <div className="eyebrow">AI COMMERCE OPERATING SYSTEM</div>
          <h1>Find the trend. Source in China. <span>Sell globally.</span></h1>
          <p>TrendDrop AI scores product demand, supplier reliability, competition, shipping cost and margin before you spend money on ads.</p>
          <div className="heroActions"><Link className="button primary" href="/admin">Open live MVP →</Link><a className="button" href="#engine">See the engine</a></div>
          <div className="trustRow"><span>✓ Supplier scoring</span><span>✓ Profit guardrails</span><span>✓ Human approval</span><span>✓ Fulfillment-ready</span></div>
        </div>
        <div className="heroPanel">
          <div className="panelHeader"><div><small>AI TREND RADAR</small><h3>Opportunity feed</h3></div><span className="liveDot">LIVE</span></div>
          {winners.map((p) => <div className="radarRow" key={p.id}>
            <div><strong>{p.name}</strong><small>{p.supplier} · {p.stage}</small></div>
            <div className="score">{opportunityScore(p)}<small>/100</small></div>
          </div>)}
          <div className="panelFoot">AI checks demand + supplier + margin + saturation + return risk</div>
        </div>
      </section>

      <section className="metrics">
        <div><strong>24/7</strong><span>trend monitoring</span></div><div><strong>4+</strong><span>China sourcing channels</span></div><div><strong>0–100</strong><span>AI opportunity score</span></div><div><strong>1</strong><span>operating dashboard</span></div>
      </section>

      <section id="engine" className="section">
        <div className="sectionHead"><div className="eyebrow">AUTOMATED WORKFLOW</div><h2>From signal to shipment</h2><p>Every stage can run automatically or stop for your approval.</p></div>
        <div className="featureGrid">
          {[
            ["01","Trend Hunter","Detects rising demand across social, search and commerce signals."],
            ["02","Supplier Match","Compares price, inventory, delivery time, reviews and reliability."],
            ["03","Profit Intelligence","Calculates landed cost, payment fees, ad allowance and minimum margin."],
            ["04","AI Listing Studio","Creates titles, descriptions, FAQs, SEO, bundles and market-specific pricing."],
            ["05","Order Router","Routes paid orders to the selected fulfillment supplier with control rules."],
            ["06","Scale / Stop AI","Flags products to scale, reprice, pause or retire as signals change."]
          ].map(([n,t,d]) => <article className="feature" key={n}><span>{n}</span><h3>{t}</h3><p>{d}</p></article>)}
        </div>
      </section>

      <section id="winners" className="section darkSection">
        <div className="sectionHead"><div className="eyebrow">CURRENT MVP DATA</div><h2>Products are ranked before import</h2></div>
        <div className="winnerGrid">{winners.map(p => <article className="winner" key={p.id}><div className="stage">{p.stage}</div><h3>{p.name}</h3><p>{p.category} · {p.supplier}</p><div className="winnerBottom"><span>Sell ${p.sell}</span><strong>{opportunityScore(p)}/100</strong></div></article>)}</div>
      </section>

      <footer><div className="brand"><span className="brandMark">T</span>TrendDrop AI</div><span>MVP · supplier APIs and payments require your production credentials.</span></footer>
    </main>
  );
}
