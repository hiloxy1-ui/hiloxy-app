-- TrendDrop AI starter schema. Apply Row Level Security before production use.
create extension if not exists pgcrypto;

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  external_id text unique,
  name text not null,
  category text,
  supplier text,
  supplier_product_id text,
  product_cost numeric(12,2) not null default 0,
  shipping_cost numeric(12,2) not null default 0,
  selling_price numeric(12,2) not null default 0,
  trend_score int check (trend_score between 0 and 100),
  opportunity_score int check (opportunity_score between 0 and 100),
  stage text default 'Emerging',
  approval_status text default 'draft',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists suppliers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  connector_type text not null,
  enabled boolean default false,
  reliability_score int,
  created_at timestamptz default now()
);

create table if not exists customer_orders (
  id uuid primary key default gen_random_uuid(),
  external_order_no text unique,
  customer_name text,
  market text,
  currency text default 'USD',
  total numeric(12,2),
  status text default 'paid',
  supplier_order_id text,
  tracking_no text,
  created_at timestamptz default now()
);

create table if not exists trend_signals (
  id uuid primary key default gen_random_uuid(),
  product_id uuid references products(id) on delete cascade,
  source text not null,
  signal_type text not null,
  score numeric(8,3),
  observed_at timestamptz default now()
);
